<template>
    <v-container>
        <v-row>
            <v-col>
                <v-card
                        max-width="550"
                >
                    <v-card-title>My Profile</v-card-title>
                    <v-card-text>
                        <v-form
                                ref="form"
                                v-model="valid"
                                lazy-validation
                        >
                            <v-text-field
                                    v-model="name"
                                    :counter="30"
                                    :rules="nameRules"
                                    label="Name"
                                    required
                            ></v-text-field>


                            <v-text-field
                                    v-model="departmentHead"
                                    :rules="departmentHeadRules"
                                    label="Head of Department"
                                    required
                            ></v-text-field>


                            <v-text-field
                                    v-model="department"
                                    :rules="departmentRules"
                                    label="Department"
                                    required
                            ></v-text-field>


                            <v-text-field
                                    v-model="title"
                                    :rules="titleRules"
                                    label="Title/Position"
                                    required
                            ></v-text-field>


                            <v-text-field
                                    v-model="degree"
                                    :rules="degreeRules"
                                    label="Degree"
                                    required
                            ></v-text-field>


                            <v-text-field
                                    v-model="email"
                                    :rules="emailRules"
                                    label="E-mail"
                                    required
                            ></v-text-field>
                        </v-form>
                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn
                                class="mr-3 mb-2"
                                color="success"
                                @click="updateProfile"
                        >
                            Update
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
    export default {
        created() {
            axios.get('/api/users/' + localStorage.userId).then(response => {
                let user = response.data.data;
                this.name = user.name;
                this.departmentHead = user.head_of_department;
                this.department = user.department;
                this.title = user.title;
                this.degree = user.degree;
                this.email = user.email;
                this.id = user.id;
            });

        },
        data: () => ({
            valid: true,

            name: '',
            nameRules: [
                v => !!v || 'Name is required',
                v => (v && v.length <= 30) || 'Name must be less than 30 characters',
            ],

            departmentHead: '',
            departmentHeadRules: [
                v => !!v || 'Please fill in head of department',
            ],

            department: '',
            departmentRules: [
                v => !!v || 'Please fill in your department',
            ],

            title: 'sdfsdf',
            titleRules: [
                v => !!v || 'Please fill in your title',
            ],

            degree: '',
            degreeRules: [
                v => !!v || 'Please fill in your degree',
            ],

            email: '',
            emailRules: [
                v => !!v || 'E-mail is required',
                v => /.+@.+\..+/.test(v) || 'E-mail must be valid',
            ],
        }),

        methods: {
            updateProfile() {
                if (this.$refs.form.validate()) {
                    axios.put('/api/users/' + this.id, {
                        name: this.name,
                        head_of_department: this.departmentHead,
                        department: this.department,
                        title: this.title,
                        degree: this.degree,
                        email: this.email,
                        id: this.id,
                    }).then(response => {
                        console.log(response);
                        this.$refs.form.resetValidation()
                    });
                }
            },
        },
    }
</script>
