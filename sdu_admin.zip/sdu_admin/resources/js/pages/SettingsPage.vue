<template>
    <v-container>
        <v-row>
            <v-col>
                <h1>Settings Page</h1>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
    export default {
        data() {
            return {

            }
        }
    }
</script>
