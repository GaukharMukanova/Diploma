<template>
    <v-container>
        <v-row>
            <v-col>
                <h1>Global Chart</h1>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="8">
                <v-col
                        v-for="(document, index) in documents"
                        cols="10"
                >
                    <v-card
                            color="grey lighten-4"
                            class="d-flex align-start flex-column pa-1"
                    >
                        <div class="d-flex justify-space-between" style="width: 100%;">
                            <div>
                                <v-card-title
                                        class="font-weight-regular"
                                >
                                    <div class="mr-4">№ {{parseInt(index) + 1}}</div><div>{{document.name}}</div>

                                </v-card-title>
                                <p class="ml-3">Author: {{document.user.name}}</p>


                                <v-card-subtitle
                                        class="body-2"
                                >
                                    <div>Category: {{document.category.name}}</div>
                                    <div>Description: {{document.description}}</div>
                                </v-card-subtitle>
                            </div>



                            <v-avatar
                                    class="ma-1"
                                    size="100"
                                    tile
                            >
                                <img src="/images/x-office-document-icon.png">
                            </v-avatar>
                        </div>

                        <div class="mt-auto" style="width: 100%">
                            <div>
                                <v-card-text
                                        class="body-2"
                                        v-html="updatedAt(document)"
                                >
                                </v-card-text>
                            </div>
                            <v-divider></v-divider>
                            <v-card-actions>
                                <v-spacer></v-spacer>

                                <v-btn
                                        color="green"
                                        medium
                                        text
                                        @click="download(document.id)"
                                >
                                    Download
                                </v-btn>
                            </v-card-actions>
                        </div>
                    </v-card>
                </v-col>

<!--                <v-pagination-->
<!--                        v-model="currentPage"-->
<!--                        :length="3"-->
<!--                        prev-icon="mdi-menu-left"-->
<!--                        next-icon="mdi-menu-right"-->
<!--                ></v-pagination>-->
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
    import moment from 'moment';

    export default {
        created() {
            this.fetchBooks();
            this.currentPage = 1;
            this.handlePagination(this.currentPage);

        },
        data() {
            return {
                paginatedDocuments: [],
                documents: [],
                currentPage: null,
            }
        },
        methods: {
            fetchBooks() {
                axios.get('/api/documents/rating')
                    .then(response => {
                        this.documents = response.data.documents;
                    });
            },
            updatedAt({updated_at, download_count}) {
                let text = '<div>Donwload count: <strong>' +  download_count + '</strong></div>';
                text +=  '<div>Last updated: <strong>' +  moment(updated_at).format("dddd, MMMM Do YYYY") + '</strong></div>';
                return text;
            },
            handlePagination(val) {
                // this.paginatedDocuments =
            }
        },
        watch: {
            currentPage: function (currentPage) {
                this.handlePagination(currentPage);

            }
        }
    }
</script>
