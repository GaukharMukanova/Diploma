import Vue from 'vue';
import VueRouter from 'vue-router';

Vue.use(VueRouter);

import ProfilePage from '../pages/ProfilePage';
import BookmarksPage from '../pages/BookmarksPage';
import SettingsPage from '../pages/SettingsPage';
import RatingsPage from '../pages/RatingsPage';

// docs
import DocsPage from '../components/docs/DocsPage';
import DocsList from '../components/docs/DocsList';
import DocsListNew from '../components/docs/DocsListNew';
import DocsListEdit from "../components/docs/DocsListEdit";

// reports
import ReportsPage from '../components/reports/ReportsPage';
import ReportList from '../components/reports/ReportList';
import ReportListShow from '../components/reports/ReportListShow';
import ReportListNew from '../components/reports/ReportListNew';

// reports: updating each section
import EditAdditional from '../components/reports/edit/EditAdditional';
import EditResearch from '../components/reports/edit/EditResearch';
import EditEducation from '../components/reports/edit/EditEducation';
import EditSocial from '../components/reports/edit/EditSocial';

import AdvancedSearchPage from '../components/AdvancedSearchPage';

const routes = [
    {
        path: '/reports',
        component: ReportsPage,
        children: [
            {
                name: 'all-reports',
                path: '/',
                component: ReportList,
            },
            {
                name: 'report-new',
                path: 'new',
                props: true,
                component: ReportListNew,
            },
            {
                name: 'report-show',
                path: ':reportId',
                props: true,
                component: ReportListShow,
            },
            {
                name: 'edit-education',
                path: ':reportId/edit-education',
                props: true,
                component: EditEducation
            },
            {
                name: 'edit-additional',
                path: ':reportId/edit-additional',
                props: true,
                component: EditAdditional
            },
            {
                name: 'edit-research',
                path: ':reportId/edit-research',
                props: true,
                component: EditResearch
            },
            {
                name: 'edit-social',
                path: ':reportId/edit-social',
                props: true,
                component: EditSocial
            },
        ]
    },
    {
        name: 'advanced-search',
        path: '/advanced-search',
        component: AdvancedSearchPage
    },
    {
        path: '/profile',
        component: ProfilePage
    },
    {
        path: '/docs',
        component: DocsPage,
        children: [
            {
                name: 'all-docs',
                path: '/',
                component: DocsList
            },
            {
                name: 'new-doc',
                path: '/new',
                component: DocsListNew
            },
            {
                name: 'edit-doc',
                path: ':documentId/edit',
                props: true,
                component: DocsListEdit,
            },

        ]
    },
    {
        name: 'history-page',
        path: '/bookmarks',
        component: BookmarksPage,
    },
    {
        name: 'analytics-page',
        path: '/analytics',
        component: RatingsPage
    },
    {
        name: 'settings-page',
        path: '/settings',
        component: SettingsPage
    },
];

export default new VueRouter({
    mode: 'history',
    base: '/',
    routes,
});
