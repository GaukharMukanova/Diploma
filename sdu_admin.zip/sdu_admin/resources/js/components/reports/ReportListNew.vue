<template>
    <div>
        <v-row>
            <v-col cols="8">
                <h2 class="display-1">
                    New report
                </h2>
            </v-col>
        </v-row>

        <v-row>

            <v-col>
                <v-card
                        max-width="550"
                        outlined
                        tile
                        elevation="2"
                >
                    <v-card-title>Create new individual report</v-card-title>
                    <v-card-text>
                        <v-select
                                v-model="year"
                                :items="years"
                                item-text="text"
                                item-value="value"
                                label="Years"
                                prepend-icon="mdi-calendar"
                        ></v-select>
                    </v-card-text>

                    <v-divider></v-divider>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn
                                color="success"
                                class="ma-2"
                                @click="createNewReport"
                        >
                            Create
                        </v-btn>
                    </v-card-actions>

                </v-card>
            </v-col>
        </v-row>
    </div>
</template>


<script>

    export default {
        created() {
            let startYear = 2019;
            for (let i = 0; 10 > i; i++) {
                this.years.push({
                    text: startYear + ' - ' + (startYear + 1),
                    value: startYear
                });
                startYear++;
            }
            this.year = this.years[0].value;
        },
        data() {
            return {
                year: null,
                years: [],
            }
        },
        methods: {
            createNewReport() {
                axios.put('/api/reports', {userId: localStorage.userId, year: this.year})
                    .then(response => {
                        if (response.data.success) {
                            this.$router.push({
                                name: 'report-show',
                                params: { reportId: response.data.reportId }
                            });
                        }
                    });
            }
        },

    }
</script>

<style scoped>
    th {
        border: 0.5px solid grey;
    }
    td {
        border: 0.5px solid grey;
    }
</style>
