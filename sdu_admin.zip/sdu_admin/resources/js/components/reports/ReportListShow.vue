<template>
    <div>
        <div class="report-list">
            <h1 class="display-2 text-center mt-4 mb-8">Report for <span class="display-3 font-weight-light">2019 - 2020</span> </h1>

            <v-row>
                <v-col cols="12">
                    <v-card class="grey lighten-3 pa-8">

                        <h1 class="display-1 text-center">
                            I-Educational methodical work
                            <v-btn text color="indigo"
                                :to="{name: 'edit-education', params: {reportId, educational}}"
                            >
                                <v-icon small>mdi-pencil</v-icon> Edit
                            </v-btn>
                        </h1>



                        <template v-for="table in educational">
                            <div class="subtitle-2 ma-2 ml-0" v-text="table.title"></div>
                            <v-data-table
                                    disable-sort
                                    :headers="table.headers"
                                    :items="table.values"
                                    hide-default-footer
                                    class="elevation-1 mb-8 ml-0"
                            ></v-data-table>
                        </template>
                    </v-card>
                </v-col>
            </v-row>

            <v-row>
                <v-col cols="12">
                    <v-card class="grey lighten-3 pa-8">

                        <h1 class="display-1 text-center mb-4">
                            II-Research work
                            <v-btn text color="indigo"
                                   :to="{name: 'edit-research', params: {reportId: reportId}}"
                            >
                                <v-icon small>mdi-pencil</v-icon> Edit
                            </v-btn>
                        </h1>


                        <template v-for="table in research">
                            <div class="subtitle-2 ma-2 ml-0" v-text="table.title"></div>
                            <v-data-table
                                    disable-sort
                                    :headers="table.headers"
                                    :items="table.values"
                                    hide-default-footer
                                    class="elevation-1 mb-8 ml-0"
                            ></v-data-table>
                        </template>


                    </v-card>


                </v-col>
            </v-row>

            <v-row>
                <v-col cols="12">
                    <v-card class="grey lighten-3  pa-8">

                        <h1 class="display-1 text-center">
                            III-Additional activities
                            <v-btn text color="indigo"
                                   :to="{name: 'edit-additional', params: {reportId: reportId}}"
                            >
                                <v-icon small>mdi-pencil</v-icon> Edit
                            </v-btn>
                        </h1>



                        <template v-for="table in additional">
                            <div class="subtitle-2 ma-2 ml-0" v-text="table.title"></div>
                            <v-data-table
                                    disable-sort
                                    :headers="table.headers"
                                    :items="table.values"
                                    hide-default-footer
                                    class="elevation-1 mb-8 ml-0"
                            ></v-data-table>
                        </template>

                    </v-card>


                </v-col>
            </v-row>

            <v-row>
                <v-col cols="12">
                    <v-card class="grey lighten-3  pa-8">

                        <h1 class="display-1 text-center">
                            IV-Social work and Service
                            <v-btn text color="indigo"
                                   :to="{name: 'edit-social', params: {reportId: reportId}}"
                            >
                                <v-icon small>mdi-pencil</v-icon> Edit
                            </v-btn>
                        </h1>



                        <template v-for="table in social">
                            <div class="subtitle-2 ma-2 ml-0" v-text="table.title"></div>
                            <v-data-table
                                    disable-sort
                                    :headers="table.headers"
                                    :items="table.values"
                                    hide-default-footer
                                    class="elevation-1 mb-8 ml-0"
                            ></v-data-table>
                        </template>

                    </v-card>


                </v-col>
            </v-row>
        </div>
    </div>
</template>


<script>

    export default {
        props: ['reportId'],
        created() {
            axios.get('/api/educations/' + this.reportId).then(response => {
                this.educational.one.values.push(response.data.data.one);
                this.educational.two.values.push(response.data.data.two);
                this.educational.three.values.push(response.data.data.three);
                this.educational.four.values.push(response.data.data.four);
                this.educational.five.values.push(response.data.data.five);
            });

            axios.get('/api/researches/' + this.reportId).then(response => {
                this.research.one.values.push(response.data.data.one.one);
                this.research.two.values.push(response.data.data.two);
                this.research.three.values.push(response.data.data.three);
                this.research.four.values.push(response.data.data.four);
                this.research.five.values.push(response.data.data.five);
                this.research.six.values.push(response.data.data.six);
                this.research.seven.values.push(response.data.data.seven);
                this.research.eight.values.push(response.data.data.eight.one);
            });

            axios.get('/api/additionls/'+ this.reportId).then(response => {
                this.additional.one.values.push(response.data.data.one);
                this.additional.two.values.push(response.data.data.two);
                this.additional.three.values.push(response.data.data.three);
            });


            axios.get('/api/socials/'+ this.reportId).then(response => {
                this.social.one.values.push(response.data.data.one);
                this.social.two.values.push(response.data.data.two);
                this.social.three.values.push(response.data.data.three);
                this.social.four.values.push(response.data.data.four);
                this.social.five.values.push(response.data.data.five);
            });
        },
        mounted() {

            setTimeout(() => {
                this.setZeroAndOne();
            }, 750);
        },
        data() {
            return {
                educational: {
                    one: {
                        title: 'Teaching materials',
                        headers: [
                            {text: 'Code-Corse title', value: 'one_title'},
                            {text: 'Number of credits', value: 'one_number'},
                            {text: 'Language', value: 'one_language'},
                            {text: 'Date of completion', value: 'one_date'},
                            {text: 'Execution', value: 'one_execution'},
                        ],
                        values: [],
                    },
                    two: {
                        title: 'Textbook/Methodological guidelines',
                        headers: [
                            {text: 'Type of Textbook', value: 'two_type'},
                            {text: 'Textbook title', value: 'two_size'},
                            {text: 'Book size (mb)', value: 'two_deadline'},
                            {text: 'Deadline', value: 'two_deadline'},
                            {text: 'Co-author', value: 'two_coauthor'},
                            {text: 'Place of publishing', value: 'two_publishing'},
                            {text: 'Execution', value: 'two_execution'},
                        ],
                        values: [],
                    },
                    three: {
                        title: 'Program of academic mobility',
                        headers: [
                            {text: 'Type of academic exchange', value: 'three_type',},
                            {text: 'Aim', value: 'three_aim'},
                            {text: 'Period', value: 'three_period'},
                            {text: 'Execution', value: 'three_execution'},
                        ],
                        values: [],
                    },
                    four: {
                        title: 'Demo lessons',
                        headers: [
                            {text: 'Course title', value: 'four_title'},
                            {text: 'Type of classes', value: 'four_type'},
                            {text: 'Topic of the classes', value: 'four_topic'},
                            {text: 'Major/Academic Group', value: 'four_group'},
                            {text: 'Date of completion', value: 'four_date'},
                            {text: 'Execution', value: 'four_execution'},
                        ],
                        values: [],
                    },
                    five: {
                        title: 'Interactive co-attending lessons',
                        headers: [
                            {text: 'Lecturer/instructor\'s name', value: 'five_name'},
                            {text: 'Course title', value: 'five_title'},
                            {text: 'Topic of the classes', value: 'five_topic'},
                            {text: 'Date of completion', value: 'five_date'},
                            {text: 'Assessment', value: 'five_assessment'},
                            {text: 'Execution', value: 'five_execution'},
                        ],
                        values: [],
                    },
                },
                research: {
                    one: {
                        title: 'Publications, articles',
                        headers: [
                            {text: 'Title', value: 'one_one_title'},
                            {text: 'Type of publication', value: 'one_one_type'},
                            {text: 'Language', value: 'one_one_language'},
                            {text: 'Issue data (journal, country, city, year, page) or media title', value: 'one_one_data'},
                            {text: 'Date of completion', value: 'one_one_date'},
                            {text: 'Execution', value: 'one_one_execution'},
                        ],
                        values: [],
                    },
                    two: {
                        title: 'Right-protective documentation (patent,pre-patent,innovational patent, copyright certificate,intellectual property certificate)',
                        headers: [
                            {text: 'Type', value: 'two_type'},
                            {text: 'Title', value: 'two_title'},
                            {text: 'No of certificate', value: 'two_number'},
                            {text: 'No of certificate', value: 'two_coauthor'},
                            {text: 'MERZIM', value: 'two_date'},
                            {text: 'Execution', value: 'two_execution'},
                        ],
                        values: [],
                    },
                    three: {
                        title: 'Monography',
                        headers: [
                            {text: 'Title', value: 'three_title',},
                            {text: 'Country/ City', value: 'three_language'},
                            {text: 'Title', value: 'three_data'},
                            {text: 'Date of completion', value: 'three_date'},
                            {text: 'Execution', value: 'three_execution'},
                        ],
                        values: [],
                    },
                    four: {
                        title: 'Joint research with RK and international universities,establishments',
                        headers: [
                            {text: 'International university', value: 'four_university'},
                            {text: 'Country/ City', value: 'four_country'},
                            {text: 'Title', value: 'four_title'},
                            {text: 'Date of completion', value: 'four_date'},
                            {text: 'Execution', value: 'four_execution'},
                        ],
                        values: [],
                    },
                    five: {
                        title: 'RK and international research projects',
                        headers: [
                            {text: 'Basic direction of scientific work', value: 'five_direction'},
                            {text: 'The title of research work', value: 'five_title'},
                            {text: 'Position in the project', value: 'five_position'},
                            {text: 'Type of funding', value: 'five_funding'},
                            {text: 'Project budget', value: 'five_budget'},
                            {text: 'Date/Period of completion', value: 'five_date'},
                            {text: 'Execution', value: 'five_execution'},
                        ],
                        values: [],
                    },
                    six: {
                        title: 'Research work with student, undergraduates and doctoral students (within HEI, university wide, national, international level)',
                        headers: [
                            {text: 'Student name', value: 'six_name'},
                            {text: 'Speciality/Program course', value: 'six_course'},
                            {text: 'Type of work', value: 'six_type'},
                            {text: 'Date/Period of completion', value: 'six_date'},
                            {text: 'Project budget City, university', value: 'six_city'},
                            {text: 'Result', value: 'six_result'},
                            {text: 'Execution', value: 'six_execution'},
                        ],
                        values: [],
                    },
                    seven: {
                        title: 'List of defended and approved PhD-dissertation/thesis under scientific supervision of academic staff',
                        headers: [
                            {text: 'Name of PhD student', value: 'seven_name'},
                            {text: 'Date of defense', value: 'seven_date'},
                            {text: 'Place of defense', value: 'seven_place'},
                            {text: 'Execution', value: 'seven_execution'},
                        ],
                        values: [],
                    },
                    eight: {
                        title: 'Acts of implementation of research results into academic process',
                        headers: [
                            {text: 'Title, speciality', value: 'eight_one_title'},
                            {text: 'Place of implementation', value: 'eight_one_place'},
                            {text: 'Form of implementation', value: 'eight_one_form'},
                            {text: 'Execution', value: 'eight_one_execution'},
                        ],
                        values: [],
                    },
                },
                additional: {
                    one: {
                        title: 'At University',
                        headers: [
                            {text: 'Type', value: 'one_type'},
                            {text: 'Country', value: 'one_country'},
                            {text: 'Title of event', value: 'one_event'},
                            {text: 'Position', value: 'one_position'},
                            {text: 'Date of issue, place', value: 'one_date'},
                            {text: 'Execution', value: 'one_execution'},
                        ],
                        values: [],
                    },
                    two: {
                        title: 'In other cases',
                        headers: [
                            {text: 'Type', value: 'two_type'},
                            {text: 'Country', value: 'two_country'},
                            {text: 'Title of event', value: 'two_event'},
                            {text: 'Position', value: 'two_position'},
                            {text: 'Date of issue, place', value: 'two_date'},
                            {text: 'Execution', value: 'two_execution'},
                        ],
                        values: [],
                    },
                    three: {
                        title: 'List of business trips',
                        headers: [
                            {text: 'Type of business trip', value: 'three_type'},
                            {text: 'Place and Date of business trip', value: 'three_place'},
                            {text: 'Aim of business trip', value: 'three_aim'},
                            {text: 'Type of funding', value: 'three_funding'},
                            {text: 'Execution', value: 'three_execution'},
                        ],
                        values: [],
                    }
                },
                social: {
                    one: {
                        title: 'Within university',
                        headers: [
                            {text: 'Type of work', value: 'one_type'},
                            {text: 'Position', value: 'one_position'},
                            {text: 'Execution', value: 'one_execution'},
                        ],
                        values: [],
                    },
                    two: {
                        title: 'In other cases',
                        headers: [
                            {text: 'Type of work', value: 'two_type'},
                            {text: 'Position', value: 'two_position'},
                            {text: 'Execution', value: 'two_execution'},
                        ],
                        values: [],
                    },
                    three: {
                        title: 'Reviews for other institutions',
                        headers: [
                            {text: 'Title', value: 'three_title',},
                            {text: 'Author', value: 'three_author'},
                            {text: 'Author', value: 'three_institution'},
                            {text: 'Execution', value: 'three_execution'},
                        ],
                        values: [],
                    },
                    four: {
                        title: 'Achievements and awards',
                        headers: [
                            {text: 'Type of work', value: 'four_type'},
                            {text: 'Result', value: 'four_result'},
                            {text: 'Place, date', value: 'four_place'},
                        ],
                        values: [],
                    },
                    five: {
                        title: 'In other cases',
                        headers: [
                            {text: 'Type of work', value: 'five_type'},
                            {text: 'Result', value: 'five_result'},
                            {text: 'Place, date', value: 'five_place'},
                        ],
                        values: [],
                    },
                },
            }
        },
        methods: {
            setZeroAndOne() {
                const replaceOnDocument = (pattern, string, {target = document.body} = {}) => {
                    [
                        target,
                        ...target.querySelectorAll("*:not(script):not(noscript):not(style)")
                    ].forEach( ({childNodes: [...nodes]}) => nodes
                        .filter(({nodeType}) => nodeType === document.TEXT_NODE)
                        .forEach((textNode) => textNode.textContent = textNode.textContent.replace(pattern, string)));
                };

                replaceOnDocument(/^1/g, "Complete");
                replaceOnDocument(/^0/g, "Not Complete");
            }
        }

    }
</script>

<style>
    .report-list th {
        border: 0.5px solid grey;
    }
    .report-list td {
        border: 0.5px solid grey;
    }
</style>
