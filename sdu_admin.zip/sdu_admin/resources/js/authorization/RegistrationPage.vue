<template>
    <v-app>

        <v-app-bar
            app
            color="primary"
            dark
        >
            <v-toolbar-title>
                Suleyman Demirel University
            </v-toolbar-title>

            <v-spacer></v-spacer>


        </v-app-bar>

        <v-content>

            <v-img height="100" contain src="./../../images/sdu-logo.png"></v-img>
            <v-card width="400" class="mx-auto">
                <v-card-title>
                    <h1 class="display-1">Register</h1>
                </v-card-title>
                <v-card-text>
                    <v-form
                        ref="form"
                        v-model="valid"
                    >
                        <v-text-field
                                v-model="name"
                                prepend-icon="mdi-account-circle"
                                label="Name"
                                type="text"
                                :rules="[rules.required]"
                        ></v-text-field>
                        <v-text-field
                                v-model="email"
                                prepend-icon="mdi-lock"
                                type="email"
                                label="Email"
                                :rules="[rules.required]"
                        ></v-text-field>
                        <v-text-field
                                v-model="password"
                                prepend-icon="mdi-lock"
                                type="password"
                                label="Password"
                                :rules="[rules.required]"
                        ></v-text-field>
                    </v-form>
                </v-card-text>
                <v-card-actions>
                    <v-btn :to="{name: 'login'}" exact text>Login page</v-btn>
                    <v-spacer></v-spacer>
                    <v-btn @click="register" color="primary">Register</v-btn>
                </v-card-actions>
            </v-card>
        </v-content>

        <v-footer
                color="primary lighten-1"
                padless
        >
            <v-row
                    justify="center"
                    no-gutters
            >
                <v-btn
                        v-for="link in footerLinks"
                        :key="link.label"
                        color="white"
                        text
                        rounded
                        class="my-2"
                        href="link.url"
                >
                    {{ link.label }}
                </v-btn>
                <v-col
                        class="primary lighten-2 py-4 text-center white--text"
                        cols="12"
                >
                    {{ new Date().getFullYear() }} — <strong>Dashboard</strong>
                </v-col>
            </v-row>
        </v-footer>


    </v-app>

</template>

<script>
export default {
    name: 'LoginPage',
    data() {
        return {
            valid: true,
            rules: {
                required: value => !!value || 'Required.'
            },

            name: '',
            email: '',
            password: '',
            footerLinks: [
                { url: 'login', label: 'Login' },
                { url: '/', label: 'Home' }
            ],
        }
    },
    methods: {
        register() {
            if (this.$refs.form.validate()) {

                axios.post('/custom-register', {
                    name: this.name,
                    email: this.email,
                    password: this.password,
                })
                    .then(response => {
                        if (response.data.success) {
                            axios.post('/login', {
                                email: this.email,
                                password: this.password
                            }).then(response => {
                                if(response.status === 204) {
                                    axios.get('/user').then(response => {
                                        localStorage.setItem("userId", response.data.id);
                                        localStorage.setItem("user", JSON.stringify(response.data))
                                        window.location.href = '/';
                                    });
                                }
                            });
                        }

                        localStorage.setItem("userId", '6');
                        localStorage.setItem("user", 'user:"{"id":6,"name":"Nomi","email":"160104059@stu.sdu.edu.kz","email_verified_at":null,"created_at":"2020-04-21T20:50:07.000000Z","updated_at":"2020-05-07T15:31:39.000000Z","head_of_department":"PHD Namazbek","department":"Department of Computer Science","title":"Associate Professor SDU","degree":"Phd"}"');
                    })
                    .catch(error => {
                        console.log(error.response.data.errors)
                    });
            }
        }
    }
}
</script>
