import Vue from 'vue';
import VueRouter from 'vue-router';

Vue.use(VueRouter);

import LoginPage from './LoginPage';
import RegistrationPage from './RegistrationPage';

const routes = [
    {
        name: 'login',
        path: '/',
        component: LoginPage,
    },
    {
        name: 'registration',
        path: '/registration',
        component: RegistrationPage,
    }
];

export default new VueRouter({
    mode: 'history',
    base: '/login',
    routes,
});
