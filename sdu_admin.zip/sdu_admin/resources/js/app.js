import Vue from 'vue';
import Main from './Main';
import store from './store';
import router from './router';
import vuetify from './plugins/vuetify';

window.axios = require('axios');
window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
let token = document.head.querySelector('meta[name="csrf-token"]');
if (token) {
    window.axios.defaults.headers.common['X-CSRF-TOKEN'] = token.content;
} else {
    console.error('CSRF token not found: https://laravel.com/docs/csrf#csrf-x-csrf-token');
}


const app = new Vue({
    store,
    router,
    vuetify,
    render: h => h(Main),
}).$mount('#app');
