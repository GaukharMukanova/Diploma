<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResearchAdditional extends Model
{
    protected $guarded = [];

    protected $table = 'research_aditionals';

    public $timestamps = false;

}
