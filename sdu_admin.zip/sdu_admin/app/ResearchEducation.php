<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResearchEducation extends Model
{
    protected $guarded = [];

    protected $table = 'research_educations';

    public $timestamps = false;

}
