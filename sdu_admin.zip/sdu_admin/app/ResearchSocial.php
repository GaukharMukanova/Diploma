<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResearchSocial extends Model
{
    protected $guarded = [];

    protected $table = 'research_socials';

    public $timestamps = false;

}
