<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResearchResearch extends Model
{
    protected $guarded = [];

    protected $table = 'research_researchs';

    public $timestamps = false;
}
